package com.example.myprodrag;

import android.view.View;

public interface RecyclerViewInterface {
    void onItemClick(int pos, View view);

}
